# How To Run ?

1. Open Tapswap Bot And Turn Off Internet ( Wifi - Cellular )

2. Click on 3 Dots On Top (Menu) And Click On Reload .

3. After Reload ,Page Shows Not Loaded Error And Link Under It :) Copy All Text ( Include Web Page Not Available )

4. Send Text To Your PC And Open Link In Browser.

5. Install TamperMonkey :

````
https://chromewebstore.google.com/detail/tampermonkey/dhdgffkkebhmkfjojejmpbldmpobfkfo?hl=en
````

6. Add New Script From Plugin Setting

7. Import tampermonkey.js ( In This Github Files ) Text In Tampermonkey Script And Save

8. Refresh Tapswap Link And See Result :)

